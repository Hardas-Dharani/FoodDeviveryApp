import 'package:flutter/material.dart';
import 'package:flutter_restaurant/data/model/response/base/api_response.dart';
import 'package:flutter_restaurant/data/model/response/config_model.dart';
import 'package:flutter_restaurant/data/model/response/response_model.dart';
import 'package:flutter_restaurant/data/model/response/static_model.dart';
import 'package:flutter_restaurant/data/repository/splash_repo.dart';
import 'package:flutter_restaurant/helper/api_checker.dart';
import 'package:intl/intl.dart';

class SplashProvider extends ChangeNotifier {
  final SplashRepo splashRepo;
  SplashProvider({@required this.splashRepo});

  ConfigModel _configModel;
  BaseUrls _baseUrls;
  StaticModel _staticModel;
  DateTime _currentTime = DateTime.now();
  bool isStaticPageLoaded = false;

  ConfigModel get configModel => _configModel;
  BaseUrls get baseUrls => _baseUrls;
  StaticModel get staticModel => _staticModel;
  DateTime get currentTime => _currentTime;

  Future<bool> initConfig(GlobalKey<ScaffoldMessengerState> globalKey) async {
    ApiResponse apiResponse = await splashRepo.getConfig();
    bool isSuccess;
    if (apiResponse.response != null &&
        apiResponse.response.statusCode == 200) {
      _configModel = ConfigModel.fromJson(apiResponse.response.data);
      _baseUrls = ConfigModel.fromJson(apiResponse.response.data).baseUrls;
      isSuccess = true;
      notifyListeners();
    } else {
      isSuccess = false;
      String _error;
      if (apiResponse.error is String) {
        _error = apiResponse.error;
      } else {
        _error = apiResponse.error.errors[0].message;
      }
      print(_error);
      globalKey.currentState.showSnackBar(
          SnackBar(content: Text(_error), backgroundColor: Colors.red));
    }
    return isSuccess;
  }

  Future<bool> initSharedData() {
    return splashRepo.initSharedData();
  }

  Future<bool> removeSharedData() {
    return splashRepo.removeSharedData();
  }

  bool isRestaurantClosed() {
    DateTime _open = DateFormat('hh:mm').parse(_configModel.restaurantOpenTime);
    DateTime _close =
        DateFormat('hh:mm').parse(_configModel.restaurantCloseTime);
    DateTime _openTime = DateTime(_currentTime.year, _currentTime.month,
        _currentTime.day, _open.hour, _open.minute);
    DateTime _closeTime = DateTime(_currentTime.year, _currentTime.month,
        _currentTime.day, _close.hour, _close.minute);
    if (_closeTime.isBefore(_openTime)) {
      _closeTime = _closeTime.add(Duration(days: 1));
    }
    if (_currentTime.isAfter(_openTime) && _currentTime.isBefore(_closeTime)) {
      return false;
    } else {
      return true;
    }
  }

  Future<ResponseModel> getStaticPageData(
      {BuildContext context, int type}) async {
    ResponseModel _responseModel;
    _staticModel = null;
    isStaticPageLoaded = false;
    ApiResponse apiResponse = await splashRepo.getStaticPageData(type: type);
    if (apiResponse.response != null &&
        apiResponse.response.statusCode == 200) {
      // ignore: unused_local_variable
      _staticModel = StaticModel.fromJson(apiResponse.response.data[0]);
      _responseModel = ResponseModel(true, 'successful');
      isStaticPageLoaded = true;
    } else {
      String _errorMessage;
      if (apiResponse.error is String) {
        _errorMessage = apiResponse.error.toString();
      } else {
        _errorMessage = apiResponse.error.errors[0].message;
      }
      print(_errorMessage);
      _responseModel = ResponseModel(false, _errorMessage);
      ApiChecker.checkApi(context, apiResponse);
    }
    notifyListeners();
    return _responseModel;
  }
}
